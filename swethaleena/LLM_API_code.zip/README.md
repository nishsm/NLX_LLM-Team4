# IP-A code (Swetaleena)

All code was run in Google Colab (T4 GPU) with Phi-4-mini-instruct.

| File | What it does |
|---|---|
| `NLX_AS01.ipynb` | AS01: builds `corpus.jsonl` from the UCI Legal Case Reports dataset, runs the Phi-4-mini extraction (ip_area, legislation_cited, relief_sought) and the human-vs-model comparison. |
| `extraction.py` | AS01 extraction script called by the AS01 notebook. |
| `AS02_LLMBox_Swetaleena.ipynb` | AS02 (Parts B–E): dev/eval baseline runs, structured output, `lookup_case` tool calling, input screening, output validation, guardrail and probe evaluation, human adjudication, and technical/cost metrics. Writes the files in `AS02/results/`. |

**Order to run:** `NLX_AS01.ipynb`, then `AS02_LLMBox_Swetaleena.ipynb`.

**Secrets:** the notebooks read `HF_TOKEN` (and, optionally, `GROQ_API_KEY`) from Colab secrets or a `.env` file. No keys are stored in these files.
