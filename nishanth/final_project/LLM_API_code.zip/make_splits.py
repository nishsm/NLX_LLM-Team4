#!/usr/bin/env python3
"""Rebuild the AS02 dev / eval / reserve splits from the AS01 corpus.

The 137 corpus records that carry a `table_json` citation table are sorted by
doc_id, shuffled with random.Random(42), and cut 50 / 50 / 37. Running this
reproduces dev_set.jsonl and eval_set.jsonl exactly (checked record by record
against the files used in AS02).

    python make_splits.py corpus.jsonl out_dir/
"""
import json
import random
import sys
from pathlib import Path


def main(corpus_path, out_dir):
    recs = [json.loads(l) for l in open(corpus_path, encoding="utf-8")]
    mixed = sorted((r for r in recs if r.get("table_json")), key=lambda r: r["doc_id"])
    random.Random(42).shuffle(mixed)
    splits = {"dev_set": mixed[:50], "eval_set": mixed[50:100], "reserve_set": mixed[100:]}
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    for name, rows in splits.items():
        with open(out / f"{name}.jsonl", "w", encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        print(name, len(rows))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else ".")
