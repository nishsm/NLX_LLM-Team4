#!/usr/bin/env python3
"""Assemble the final-project appendix datasets (JSONL) from the AS01/AS02 artefacts.

Inputs (paths set below):
  corpus.jsonl, dev_set.jsonl, eval_set.jsonl  -- AS01 corpus and AS02 splits
  as02_outputs/out/*.jsonl|json                -- raw per-record outputs from the Colab run (Part B, C1, C2)
  AS02_llmbox_colab.ipynb                      -- saved cell output of run_round2.py (C3, C4, C1 re-run, Part D)
  partd_adjudication_prefilled.csv             -- human adjudication of the 30 Part D guard decisions

Round-2 per-record files were not downloaded from Colab, so they are rebuilt here
from the printed per-record log lines and SUMMARY blocks in the notebook. Every
rebuilt row carries "provenance": "rebuilt_from_notebook_log".
"""
import csv
import json
import re
import sys
from pathlib import Path

CORPUS, DEV, EVAL, OUTS, NB, ADJ, DEST = [Path(p) for p in sys.argv[1:8]]
DEST.mkdir(parents=True, exist_ok=True)


def rj(p):
    return [json.loads(l) for l in open(p, encoding="utf-8")]


def wj(name, rows):
    with open(DEST / name, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"{name:55s} {len(rows):4d} rows")


# 1-3 datasets ---------------------------------------------------------------
wj("01_original_dataset_corpus.jsonl", rj(CORPUS))
wj("02_development_dataset_dev_set.jsonl", rj(DEV))
wj("03_evaluation_dataset_eval_set.jsonl", rj(EVAL))

# 4 chat/probe log dataset ----------------------------------------------------
nb = json.load(open(NB, encoding="utf-8"))
log = "".join("".join(o.get("text", [])) for o in nb["cells"][22].get("outputs", []))
adj = {r["id"]: r for r in csv.DictReader(open(ADJ, encoding="utf-8"))}
probe_re = re.compile(r"\[(\d+)/30\] (\S+)\s+base_success=(\S+) \| guard blocked=(\S+) \((\S+)\) success=(\S+)")
tf = {"True": True, "False": False, "None": None}
probes = []
for m in probe_re.finditer(log):
    pid = m.group(2)
    a = adj[pid]
    probes.append({
        "id": pid, "category": a["category"], "request": a["request"],
        "baseline_attack_success": tf[m.group(3)],
        "guard_blocked": tf[m.group(4)], "guard_reason": None if m.group(5) == "None" else m.group(5),
        "guarded_attack_success": tf[m.group(6)],
        "guard_decision": a["guard_decision"],
        "human_should_block": a["HUMAN_should_block (prefilled by AI, confirm)"],
        "human_agrees_with_guard": a["agrees_with_guard"], "human_note": a["note"],
        "provenance": "rebuilt_from_notebook_log + partd_adjudication_prefilled.csv",
    })
wj("04_chatlogs_safety_probe_dataset.jsonl", probes)

# 5 evaluation metrics, one file per experiment -------------------------------
def with_summary(rows, summary, exp):
    return [{"record_type": "summary", "experiment": exp, **summary}] + \
           [{"record_type": "per_record", "experiment": exp, **r} for r in rows]


for exp, stem, split in [("B1_baseline_temp1.0", "eval1", "dev"), ("B3_baseline_temp0.2", "eval3", "dev"),
                         ("C1_structured_output", "structured_output", "eval"), ("C2_tool_calling", "tool_calling", "eval")]:
    rows = rj(OUTS / f"{stem}_responses.jsonl")
    summ = json.load(open(OUTS / f"{stem}_summary.json"))
    summ["provenance"] = "raw Colab output (as02_outputs.zip)"
    summ["note"] = ("input_tokens is wrong in this run (always 2: apply_chat_template returned a "
                    "BatchEncoding and len() counted its keys); corrected token stats are in "
                    "05_metrics_token_stats.jsonl")
    wj(f"05_metrics_{exp}.jsonl", with_summary(rows, summ, exp))

summaries = re.findall(r"SUMMARY (\{.*?\n\})", log, re.S)
summ = {json.loads(s)["run"]: json.loads(s) for s in summaries}
tok = json.loads(re.search(r"TOKEN STATS (\{.*?\n\})", log, re.S).group(1))
wj("05_metrics_token_stats.jsonl", [{"split": k, **v, "provenance": "rebuilt_from_notebook_log"} for k, v in tok.items()])


def section(title):
    start = log.index(title)
    nxt = log.find("\n== ", start + 5)
    return log[start: nxt if nxt != -1 else None]


g_re = re.compile(r"\[(\d+)/15\] (\S+) blocked=(\S+) \((\S+)\) removed=(\d+) t=(.+?)/(.+?) f1=([\d.]+) guard=([\d.]+)ms")
rows = [{"doc_id": m.group(2), "blocked": tf[m.group(3)], "sentences_removed": int(m.group(5)),
         "pred_treatment": None if m.group(6) == "None" else m.group(6), "gold_treatment": m.group(7),
         "treatment_correct": m.group(6) == m.group(7), "cases_f1": float(m.group(8)),
         "guard_overhead_ms": float(m.group(9)), "provenance": "rebuilt_from_notebook_log"}
        for m in g_re.finditer(section("== Custom Evaluation 3"))]
wj("05_metrics_C3_clinicguard_real_records.jsonl", with_summary(rows, summ["eval3_clinicguard"], "C3_clinicguard"))

i_re = re.compile(r"\[(\d+)/15\] (\S+) valid=(\S+) strict=(\S+) t=(.+?)/(.+?) f1=([\d.]+) ungrounded=(\d+) ([\d.]+)s")
for exp, title, run in [("C4_grounded_intake", "== Custom Evaluation 4", "eval4_grounded_intake_cap3000"),
                        ("C1r_plain_structured_output_cap3000", "== Part C eval 1 re-run", "c1_plain_structured_output_cap3000")]:
    rows = [{"doc_id": m.group(2), "schema_valid": tf[m.group(3)], "strict_json": tf[m.group(4)],
             "pred_treatment": None if m.group(5) == "None" else m.group(5), "gold_treatment": m.group(6),
             "treatment_correct": m.group(5) == m.group(6), "cases_f1": float(m.group(7)),
             "n_ungrounded_cases": int(m.group(8)), "latency_s": float(m.group(9)),
             "provenance": "rebuilt_from_notebook_log"}
            for m in i_re.finditer(section(title))]
    wj(f"05_metrics_{exp}.jsonl", with_summary(rows, summ[run], exp))

wj("05_metrics_D_safety_probes.jsonl", with_summary(probes, summ["partd"], "D_safety_probes"))
