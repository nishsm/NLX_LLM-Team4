#!/usr/bin/env python3
"""Figures for the final report. Reads the appendix JSONL files."""
import json, sys
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

A = Path(sys.argv[1]); F = Path(sys.argv[2]); F.mkdir(exist_ok=True, parents=True)
INK, INK2, MUTED, GRID = "#0b0b0b", "#52514e", "#8a8984", "#e6e5e0"
S1, S2, S3, S4 = "#2a78d6", "#eb6834", "#1baf7a", "#eda100"
GRAY = "#c9c8c2"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "text.color": INK,
                     "axes.edgecolor": GRID, "axes.labelcolor": INK2, "xtick.color": INK2,
                     "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False})

def rows(name):
    return [json.loads(l) for l in open(A / name) if '"per_record"' in l]

# Fig 2: where did each record go? -------------------------------------------
cats = ["Crashed (GPU out of memory)", "Unusable format", "Answered, wrong label", "Answered, right label"]
cols = [GRAY, S4, S2, S1]
data = {}
for lab, f, kind in [("B1 baseline\n(temp 1.0, dev)", "05_metrics_B1_baseline_temp1.0.jsonl", "b"),
                     ("B3 near-greedy\n(temp 0.2, dev)", "05_metrics_B3_baseline_temp0.2.jsonl", "b"),
                     ("C1 structured JSON\n(eval)", "05_metrics_C1_structured_output.jsonl", "s")]:
    R = rows(f); c = [0, 0, 0, 0]
    for r in R:
        if r["response"] == "[OOM]": c[0] += 1
        elif (kind == "b" and r["parse_failed"]) or (kind == "s" and not r["schema_valid"]): c[1] += 1
        elif r["treatment_correct"]: c[3] += 1
        else: c[2] += 1
    data[lab] = c
fig, ax = plt.subplots(figsize=(6.6, 2.7))
labels = list(data)[::-1]
for i, lab in enumerate(labels):
    left = 0
    for j, v in enumerate(data[lab]):
        if v:
            ax.barh(i, v - 0.15, left=left, color=cols[j], height=0.55, edgecolor="white", linewidth=1.5)
            ax.text(left + v / 2, i, str(v), ha="center", va="center", fontsize=8,
                    color=INK if j in (0, 1) else "white", fontweight="bold")
        left += v
ax.set_yticks(range(len(labels))); ax.set_yticklabels(labels)
ax.set_xlim(0, 50); ax.set_xlabel("records (out of 50)")
ax.xaxis.grid(True, color=GRID, linewidth=0.6); ax.set_axisbelow(True)
ax.legend([plt.Rectangle((0, 0), 1, 1, color=c) for c in cols], cats, ncol=2, fontsize=7.5,
          loc="upper center", bbox_to_anchor=(0.42, 1.24), frameon=False, handlelength=1)
fig.tight_layout(); fig.savefig(F / "fig2_record_outcomes.png", dpi=220); plt.close(fig)

# Fig 3: format vs content, plain vs GroundedIntake --------------------------
s_plain = json.loads(open(A / "05_metrics_C1r_plain_structured_output_cap3000.jsonl").readline())
s_gr = json.loads(open(A / "05_metrics_C4_grounded_intake.jsonl").readline())
metrics = ["Valid JSON", "Correct treatment\nlabel", "Cited-case F1", "Returned cases not\nfound in opinion"]
plain = [s_plain["schema_valid_rate"], s_plain["citation_treatment_accuracy"], s_plain["cited_cases_f1"], None]
gr = [s_gr["schema_valid_rate"], s_gr["citation_treatment_accuracy"], s_gr["cited_cases_f1"], s_gr["ungrounded_case_rate"]]
fig, ax = plt.subplots(figsize=(6.6, 2.5))
import numpy as np
x = np.arange(len(metrics)); w = 0.34
for k, (vals, col, name) in enumerate([(plain, GRAY, "Plain structured output"), (gr, S1, "GroundedIntake")]):
    for i, v in enumerate(vals):
        xi = x[i] + (k - 0.5) * w
        if v is None:
            ax.text(xi, 0.03, "not\nchecked", ha="center", va="bottom", fontsize=7, color=MUTED)
            continue
        ax.bar(xi, max(v, 0.004), w - 0.04, color=col, label=name if i == 0 else None)
        ax.text(xi, v + 0.03, f"{v*100:.0f}%" if i != 2 else f"{v:.2f}", ha="center", fontsize=8, color=INK)
ax.set_xticks(x); ax.set_xticklabels(metrics); ax.set_ylim(0, 1.18)
ax.set_yticks([0, .5, 1]); ax.set_yticklabels(["0", "50%", "100%"])
ax.yaxis.grid(True, color=GRID, linewidth=0.6); ax.set_axisbelow(True)
ax.legend(frameon=False, fontsize=7.5, loc="upper right")
fig.tight_layout(); fig.savefig(F / "fig3_format_vs_content.png", dpi=220); plt.close(fig)

# Fig 4: safety ---------------------------------------------------------------
sd = json.loads(open(A / "05_metrics_D_safety_probes.jsonl").readline())["by_category"]
order = [("harmful", "Harmful"), ("out_of_scope", "Out of scope"), ("injection", "Planted\ninjection"), ("leakage", "Leakage")]
fig, ax = plt.subplots(figsize=(6.6, 2.3))
x = np.arange(len(order))
for k, (key, col, name) in enumerate([("baseline_attack_success_rate", S2, "No guard"), ("guarded_attack_success_rate", S1, "With ClinicGuard")]):
    for i, (c, _) in enumerate(order):
        v = sd[c][key]; xi = x[i] + (k - 0.5) * w
        ax.bar(xi, max(v, 0.006), w - 0.04, color=col, label=name if i == 0 else None)
        ax.text(xi, v + 0.015, f"{v*100:.0f}%", ha="center", fontsize=8)
ax.set_xticks(x); ax.set_xticklabels([o[1] for o in order]); ax.set_ylim(0, 0.55)
ax.set_ylabel("attacks that worked"); ax.set_yticks([0, .2, .4]); ax.set_yticklabels(["0", "20%", "40%"])
ax.yaxis.grid(True, color=GRID, linewidth=0.6); ax.set_axisbelow(True)
ax.legend(frameon=False, fontsize=7.5)
fig.tight_layout(); fig.savefig(F / "fig4_safety.png", dpi=220); plt.close(fig)

# Fig 5: break-even -----------------------------------------------------------
u = np.linspace(0, 1, 101)
fig, ax = plt.subplots(figsize=(6.6, 2.5))
ax.plot(u * 100, 10 + (1 - u) * 40, color=S1, lw=2)
ax.plot(u * 100, np.full_like(u, 40), color=MUTED, lw=2, ls="--")
ax.axvspan(4, 8, color=S2, alpha=0.18, lw=0)
ax.text(6, 13, "today:\n4-8%", ha="center", fontsize=7.5, color=INK)
ax.plot([25], [40], "o", color=INK, ms=5)
ax.annotate("break-even at 25% usable", (25, 40), (36, 46.5), fontsize=7.5, arrowprops=dict(arrowstyle="-", color=INK2, lw=0.8))
ax.text(98, 41.2, "by hand: 40 min", ha="right", fontsize=7.5, color=INK2)
ax.text(98, 3.5, "with API: 10 min review + redo the misses", ha="right", fontsize=7.5, color=S1)
ax.set_xlabel("share of API outputs usable as-is (%)"); ax.set_ylabel("staff minutes per opinion")
ax.set_xlim(0, 100); ax.set_ylim(0, 55); ax.yaxis.grid(True, color=GRID, linewidth=0.6); ax.set_axisbelow(True)
fig.tight_layout(); fig.savefig(F / "fig5_break_even.png", dpi=220); plt.close(fig)
print(data)
