# LLM API code: Immigration legal aid clinic precedent-research API

Author: Nishanth Madthila. Course: 95-820 Applications of NL(X) and LLM, Final Project.

- `make_splits.py` rebuilds the dev/eval/reserve splits from corpus.jsonl (seed 42).
- `as02/` contains the LLMBox evaluation scripts:
  - Part B: `run_baseline_eval.py`
  - Part C1/C2: `run_custom_eval.py`
  - ClinicGuard, GroundedIntake and Part D: `run_round2.py`
  - The `verify_citation` tool: `src/tools.py`
  - The schema, the citation index and the Colab notebook
- `as01/` contains corpus construction and the Human-vs-Phi extraction pipeline.
- `build_appendix.py` and `make_figures.py` regenerate the submitted JSONL appendix and the report figures.

These scripts run inside the LLMBox repository: copy the `as02/` files into `llmbox-main/`.
Settings: Phi-4-mini-instruct loaded locally, float16 on a T4, seed 42, max_new_tokens 512.
Input caps: 6000 tokens in round 1 and 3000 in round 2.
See Appendix C of the report for the full steps.
