#!/usr/bin/env python3
"""Part C: custom LLMBox evaluations for the legal aid clinic scenario.

  structured_output -- case-intake extraction constrained to the Pydantic-
      derived JSON schema in schemas/case_intake.json. Scored on schema
      validity, citation_treatment accuracy, cited_cases P/R/F1.

  tool_calling -- the model names the main case an opinion cites and must
      check it with verify_citation (src/tools.py) before answering: the
      clinic's "catch a hallucinated citation before it is filed" task.
      Scored on tool-call rate, whether the checked case is real (in the
      opinion's own table_json), and whether the model's final answer
      agrees with what the tool actually returned.

    python run_custom_eval.py --task structured_output --limit 50
    python run_custom_eval.py --task tool_calling --limit 50
"""
import argparse
import json
import re
import time
from collections import Counter
from pathlib import Path

from hydra import initialize, compose
from src.schema import register_configs
from src.generation import GenerationManager

STRUCT_SYSTEM_PROMPT = (
    "You are assisting a legal aid clinic's case-intake process. You will be "
    "shown the full text of an Australian Federal Court opinion. Extract the "
    "visa category, how the opinion treats the main precedent it cites, and "
    "the cases it cites."
)

TOOL_SYSTEM_PROMPT = (
    "You are assisting a legal aid clinic's precedent-research task. Before "
    "any case citation goes into a brief, the clinic requires you to verify it "
    "with the verify_citation tool. Read the opinion, identify the single most "
    "important case it cites, call verify_citation with that exact case name, "
    "and then reply with exactly two lines:\n"
    "CASE: <the case name you checked>\n"
    "VERIFIED: <true or false, exactly as the tool reported>"
)

TOOLS = [{
    "name": "verify_citation",
    "description": "Check whether a case citation is a real, known citation before including it in a legal brief.",
    "parameters": {
        "type": "object",
        "properties": {"case_name": {"type": "string",
                                     "description": "The case name/citation to verify, exactly as it appears in the opinion."}},
        "required": ["case_name"],
    },
}]


def gold_for(record):
    table = record.get("table_json") or []
    classes = Counter(c["citation_class"] for c in table if c.get("citation_class"))
    gold_treatment = classes.most_common(1)[0][0] if classes else None
    return gold_treatment, [c["cited_case"] for c in table]


def score_cases(pred, gold):
    pred_set = {str(p).strip().lower() for p in pred}
    gold_set = {g.strip().lower() for g in gold}
    if not pred_set and not gold_set:
        return 1.0, 1.0, 1.0
    tp = len(pred_set & gold_set)
    precision = tp / len(pred_set) if pred_set else 0.0
    recall = tp / len(gold_set) if gold_set else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
    return precision, recall, f1


def extract_json(text):
    """Strict first (the API contract), then a lenient fallback that strips a
    ```json fence -- reported separately so the memo can show both."""
    try:
        return json.loads(text), True
    except json.JSONDecodeError:
        pass
    m = re.search(r"\{.*\}", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(0)), False
        except json.JSONDecodeError:
            pass
    return None, False


def count_tokens(tokenizer, messages, response):
    in_ids = tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True)
    if isinstance(in_ids, dict):
        in_ids = in_ids["input_ids"]
    return len(in_ids), len(tokenizer(response, add_special_tokens=False)["input_ids"])


def run_structured_output(args, records, gen, model, tokenizer, device, cfg):
    schema_text = Path(args.schema_path).read_text(encoding="utf-8")
    system = (STRUCT_SYSTEM_PROMPT + "\n\nRespond with ONLY a single JSON object that strictly "
              f"matches this JSON Schema, with no other text:\n{schema_text}")
    rows = []
    for i, record in enumerate(records):
        messages = [{"role": "system", "content": system},
                    {"role": "user", "content": f"Opinion:\n{record['raw_text']}"}]
        t0 = time.time()
        response = gen._generate_once(model, tokenizer, device, messages, cfg)
        latency = time.time() - t0
        in_tok, out_tok = count_tokens(tokenizer, messages, response)
        gold_treatment, gold_cases = gold_for(record)
        parsed, strict_ok = extract_json(response)
        required = ("visa_category", "citation_treatment", "cited_cases")
        schema_valid = isinstance(parsed, dict) and all(k in parsed for k in required)
        echoed_schema = isinstance(parsed, dict) and "properties" in parsed and "visa_category" not in parsed
        pred_treatment = parsed.get("citation_treatment") if schema_valid else None
        pred_cases = (parsed.get("cited_cases") or []) if schema_valid else []
        if not isinstance(pred_cases, list):
            pred_cases = [pred_cases]
        precision, recall, f1 = score_cases(pred_cases, gold_cases)
        row = {
            "doc_id": record["doc_id"], "response": response,
            "strict_json": strict_ok, "schema_valid": schema_valid, "echoed_schema": echoed_schema,
            "pred_visa_category": parsed.get("visa_category") if schema_valid else None,
            "pred_treatment": pred_treatment, "gold_treatment": gold_treatment,
            "treatment_correct": (pred_treatment == gold_treatment) if gold_treatment else None,
            "cases_precision": precision, "cases_recall": recall, "cases_f1": f1,
            "input_tokens": in_tok, "output_tokens": out_tok, "latency_s": round(latency, 2),
        }
        rows.append(row)
        print(f"  [{i+1}/{len(records)}] {record['doc_id']}  valid={schema_valid} strict={strict_ok} "
              f"echo={echoed_schema} treatment={pred_treatment} f1={f1:.2f} {latency:.1f}s", flush=True)
    return rows


def run_tool_calling(args, records, gen, model, tokenizer, device, cfg):
    rows = []
    for i, record in enumerate(records):
        _, gold_cases = gold_for(record)
        gold_set = {g.strip().lower() for g in gold_cases}
        messages = [{"role": "system", "content": gen.build_functools_system_prompt(TOOL_SYSTEM_PROMPT, TOOLS)},
                    {"role": "user", "content": f"Opinion:\n{record['raw_text']}"}]
        first_turn = list(messages)
        t0 = time.time()
        answer, calls = gen.run_tool_turn(model, tokenizer, device, messages, cfg)
        latency = time.time() - t0
        in_tok, out_tok = count_tokens(tokenizer, first_turn, answer)
        tool_called = len(calls) > 0
        checked_case = (calls[0].get("arguments") or {}).get("case_name") if tool_called else None
        tool_verified = (calls[0].get("result") or {}).get("verified") if tool_called else None
        case_is_real = (str(checked_case).strip().lower() in gold_set) if checked_case else None
        m = re.search(r"VERIFIED:\s*(true|false)", answer, re.IGNORECASE)
        claimed = (m.group(1).lower() == "true") if m else None
        consistent = (claimed == tool_verified) if (claimed is not None and tool_verified is not None) else None
        row = {
            "doc_id": record["doc_id"], "answer": answer, "tool_calls": calls,
            "tool_called": tool_called, "checked_case": checked_case,
            "case_in_opinion_table": case_is_real, "tool_verified": tool_verified,
            "model_claimed_verified": claimed, "model_consistent_with_tool": consistent,
            "claimed_verified_without_tool": (claimed is True and not tool_called),
            "input_tokens": in_tok, "output_tokens": out_tok, "latency_s": round(latency, 2),
        }
        rows.append(row)
        print(f"  [{i+1}/{len(records)}] {record['doc_id']}  tool={tool_called} case={str(checked_case)[:50]!r} "
              f"verified={tool_verified} claimed={claimed} {latency:.1f}s", flush=True)
    return rows


def rate(rows, key):
    vals = [r[key] for r in rows if r[key] is not None]
    return round(sum(vals) / len(vals), 3) if vals else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", choices=["structured_output", "tool_calling"], required=True)
    ap.add_argument("--split", choices=["dev", "eval"], default="eval")
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--model-local-path", default="/content/models/Phi-4-mini-instruct")
    ap.add_argument("--dtype", default="float16")
    ap.add_argument("--schema-path", default="schemas/case_intake.json")
    ap.add_argument("--temperature", type=float, default=0.2)
    ap.add_argument("--top-p", type=float, default=0.9)
    ap.add_argument("--max-new-tokens", type=int, default=512)
    args = ap.parse_args()

    records = [json.loads(l) for l in open(f"{args.split}_set.jsonl", encoding="utf-8")]
    if args.limit:
        records = records[:args.limit]
    print(f"Loaded {len(records)} records from {args.split}_set.jsonl", flush=True)

    register_configs()
    with initialize(version_base=None, config_path="conf"):
        cfg = compose(config_name="config", overrides=[
            "model=phi4_instruct", f"mode={args.task}",
            f"model.local_path={args.model_local_path}",
            f"model.dtype={args.dtype}",
            f"generation.temperature={args.temperature}",
            f"generation.top_p={args.top_p}",
            f"generation.max_new_tokens={args.max_new_tokens}",
        ])
    gen = GenerationManager()
    model, tokenizer, device = gen._load_model_and_tokenizer(cfg)
    print(f"Model on {device}. task={args.task}", flush=True)

    t_start = time.time()
    run = run_structured_output if args.task == "structured_output" else run_tool_calling
    rows = run(args, records, gen, model, tokenizer, device, cfg)

    Path("out").mkdir(exist_ok=True)
    with open(Path("out") / f"{args.task}_responses.jsonl", "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")

    n = len(rows)
    summary = {"task": args.task, "split": args.split, "n_records": n,
               "hyperparameters": {"temperature": args.temperature, "top_p": args.top_p,
                                   "max_new_tokens": args.max_new_tokens}}
    if args.task == "structured_output":
        summary.update({
            "strict_json_rate": rate(rows, "strict_json"),
            "schema_valid_rate": rate(rows, "schema_valid"),
            "schema_echo_rate": rate(rows, "echoed_schema"),
            "citation_treatment_accuracy": rate(rows, "treatment_correct"),
            "cited_cases_precision": round(sum(r["cases_precision"] for r in rows) / n, 3),
            "cited_cases_recall": round(sum(r["cases_recall"] for r in rows) / n, 3),
            "cited_cases_f1": round(sum(r["cases_f1"] for r in rows) / n, 3),
        })
    else:
        summary.update({
            "tool_call_rate": rate(rows, "tool_called"),
            "checked_case_in_opinion_rate": rate(rows, "case_in_opinion_table"),
            "tool_verified_rate": rate(rows, "tool_verified"),
            "model_consistent_with_tool_rate": rate(rows, "model_consistent_with_tool"),
            "claimed_verified_without_tool_rate": rate(rows, "claimed_verified_without_tool"),
        })
    summary.update({
        "mean_input_tokens": round(sum(r["input_tokens"] for r in rows) / n, 1),
        "mean_output_tokens": round(sum(r["output_tokens"] for r in rows) / n, 1),
        "mean_latency_s": round(sum(r["latency_s"] for r in rows) / n, 2),
        "total_time_s": round(time.time() - t_start, 1),
        "device": str(device),
    })
    (Path("out") / f"{args.task}_summary.json").write_text(json.dumps(summary, indent=2))
    print("\nSUMMARY " + json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
