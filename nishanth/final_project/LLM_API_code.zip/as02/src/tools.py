'''
    LLMBox -- A Software Application for Building Customized and Affordable AI Solutions.
    Copyright (C) 2026  Sara Kingsley

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
'''

"""
tools.py

Example tool implementations for mode=tool_calling. When a model's chat
template doesn't have native structured tool-calling support and instead
uses a convention like Phi-4-mini-instruct's <|tool|>...<|/tool|> system
prompt + "functools[...]" response marker (see
GenerationManager.build_functools_system_prompt / parse_tool_calls /
run_tool_turn in generation.py), the model's requested tool name is looked
up here and actually executed locally.

Swap these out for whatever you actually want the model to be able to
call. Each tool needs:
  1. An entry under `tool_calling.tools` in your config (name, description,
     and a JSON-schema `parameters` block) -- that's what gets shown to the
     model.
  2. A matching Python callable registered here under the same name --
     that's what actually runs when the model asks for it.
"""

TOOL_REGISTRY = {}


def register_tool(name):
    def decorator(func):
        TOOL_REGISTRY[name] = func
        return func
    return decorator


@register_tool("get_current_weather")
def get_current_weather(location, unit="celsius"):
    # Stub data -- replace this body with a real weather API call.
    fake_data = {"Paris, France": 18, "New York, USA": 22, "Tokyo, Japan": 27}
    temp_c = fake_data.get(location, 20)
    temp = temp_c if unit == "celsius" else round(temp_c * 9 / 5 + 32, 1)
    return {"location": location, "temperature": temp, "unit": unit}


@register_tool("calculate")
def calculate(expression):
    allowed_chars = set("0123456789+-*/(). ")
    if not set(expression) <= allowed_chars:
        return {"error": "Expression contains disallowed characters."}
    try:
        result = eval(expression, {"__builtins__": {}}, {})
        return {"result": result}
    except Exception as exc:  # noqa: BLE001 - want to surface any eval error to the model
        return {"error": str(exc)}


# --------------------------------------------------------------------------
# verify_citation -- the legal aid clinic's real tool_calling use case:
# before a case citation goes into a filed brief, check it against a known
# citation index (built from the corpus's own table_json annotations) to
# catch a hallucinated or misremembered case name before it reaches a
# filing. Returns verified=False for anything not in the index, which is
# the correct, safe default (absence of evidence is not evidence the
# citation is fake, but this tool can only confirm, never deny).
# --------------------------------------------------------------------------
import json as _json
from pathlib import Path as _Path

_CITATION_INDEX_PATH = _Path(__file__).resolve().parent.parent / "citation_index.json"
try:
    _CITATION_INDEX = _json.loads(_CITATION_INDEX_PATH.read_text(encoding="utf-8"))
except FileNotFoundError:
    _CITATION_INDEX = {}


@register_tool("verify_citation")
def verify_citation(case_name):
    """Check whether `case_name` appears in the clinic's known-citation
    index (876 citations drawn from the corpus's own table_json). Exact
    match only, case-insensitive -- a real deployment would use fuzzy
    matching, but exact match keeps the tool's behavior easy to audit for
    this assignment."""
    if not isinstance(case_name, str) or not case_name.strip():
        return {"verified": False, "error": "case_name must be a non-empty string"}
    needle = case_name.strip().lower()
    for known_name, meta in _CITATION_INDEX.items():
        if known_name.strip().lower() == needle:
            return {
                "verified": True,
                "matched_name": known_name,
                "citation_class_in_corpus": meta.get("citation_class"),
            }
    return {"verified": False, "matched_name": None}
