#!/usr/bin/env python3
"""Part B: Baseline LLMBox 'generate' mode evaluation (legal aid clinic
precedent-research task). Extract citation_treatment + cited_cases from an
opinion's raw_text; score against the record's own table_json annotations.

    python run_baseline_eval.py --split dev --run-name eval1 --temperature 1.0 --top-p 0.95 --limit 50
    python run_baseline_eval.py --split dev --run-name eval3 --temperature 0.2 --top-p 0.9  --limit 50
"""
import argparse
import json
import re
import time
from collections import Counter
from pathlib import Path

from hydra import initialize, compose
from src.schema import register_configs
from src.generation import GenerationManager

VALID_TREATMENTS = [
    "cited", "referred to", "applied", "followed", "considered", "discussed",
    "distinguished", "quoted", "related", "affirmed", "approved",
]

SYSTEM_PROMPT = (
    "You are assisting a legal aid clinic's precedent-research task. You will "
    "be shown the full text of an Australian Federal Court opinion. Read it "
    "and answer in exactly this format, with no other text:\n\n"
    "CITATION TREATMENT: <one of: cited, referred to, applied, followed, "
    "considered, discussed, distinguished, quoted, related, affirmed, approved>\n"
    "CITED CASES: <semicolon-separated list of case names/citations exactly as "
    "they appear in the opinion, or 'none' if there are none>"
)


def parse_response(text):
    treatment = None
    m = re.search(r"CITATION TREATMENT:\s*(.+)", text, re.IGNORECASE)
    if m:
        candidate = m.group(1).strip().strip(".").lower()
        for v in VALID_TREATMENTS:
            if v in candidate:
                treatment = v
                break
    cases = []
    m = re.search(r"CITED CASES:\s*(.+)", text, re.IGNORECASE | re.DOTALL)
    if m:
        raw = m.group(1).strip()
        if raw.lower() not in ("none", "none.", ""):
            parts = raw.split(";") if ";" in raw else raw.split("\n")
            cases = [p.strip().strip(".").lstrip("-* ").strip() for p in parts if p.strip()]
    return treatment, cases


def gold_for(record):
    table = record.get("table_json") or []
    classes = Counter(c["citation_class"] for c in table if c.get("citation_class"))
    gold_treatment = classes.most_common(1)[0][0] if classes else None
    return gold_treatment, [c["cited_case"] for c in table]


def score_cases(pred, gold):
    pred_set = {p.strip().lower() for p in pred}
    gold_set = {g.strip().lower() for g in gold}
    if not pred_set and not gold_set:
        return 1.0, 1.0, 1.0
    tp = len(pred_set & gold_set)
    precision = tp / len(pred_set) if pred_set else 0.0
    recall = tp / len(gold_set) if gold_set else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
    return precision, recall, f1


def count_tokens(tokenizer, messages, response):
    in_ids = tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True)
    if isinstance(in_ids, dict):
        in_ids = in_ids["input_ids"]
    out_ids = tokenizer(response, add_special_tokens=False)["input_ids"]
    return len(in_ids), len(out_ids)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", choices=["dev", "eval"], required=True)
    ap.add_argument("--run-name", required=True)
    ap.add_argument("--model-local-path", default="/content/models/Phi-4-mini-instruct")
    ap.add_argument("--dtype", default="float16")
    ap.add_argument("--temperature", type=float, default=1.0)
    ap.add_argument("--top-p", type=float, default=0.95)
    ap.add_argument("--max-new-tokens", type=int, default=512)
    ap.add_argument("--limit", type=int, default=None)
    args = ap.parse_args()

    records = [json.loads(l) for l in open(f"{args.split}_set.jsonl", encoding="utf-8")]
    if args.limit:
        records = records[:args.limit]
    print(f"Loaded {len(records)} records from {args.split}_set.jsonl", flush=True)

    register_configs()
    with initialize(version_base=None, config_path="conf"):
        cfg = compose(config_name="config", overrides=[
            "model=phi4_instruct", "mode=generate",
            f"model.local_path={args.model_local_path}",
            f"model.dtype={args.dtype}",
            f"generation.temperature={args.temperature}",
            f"generation.top_p={args.top_p}",
            f"generation.max_new_tokens={args.max_new_tokens}",
        ])
    cfg.system_prompt = SYSTEM_PROMPT

    gen = GenerationManager()
    model, tokenizer, device = gen._load_model_and_tokenizer(cfg)
    print(f"Model on {device}. temperature={args.temperature} top_p={args.top_p} "
          f"max_new_tokens={args.max_new_tokens}", flush=True)

    Path("out").mkdir(exist_ok=True)
    out_path = Path("out") / f"{args.run_name}_responses.jsonl"
    rows = []
    t_start = time.time()
    with open(out_path, "w", encoding="utf-8") as outf:
        for i, record in enumerate(records):
            messages = [
                {"role": "system", "content": cfg.system_prompt},
                {"role": "user", "content": f"Opinion:\n{record['raw_text']}"},
            ]
            t0 = time.time()
            response = gen._generate_once(model, tokenizer, device, messages, cfg)
            latency = time.time() - t0
            in_tok, out_tok = count_tokens(tokenizer, messages, response)
            pred_treatment, pred_cases = parse_response(response)
            gold_treatment, gold_cases = gold_for(record)
            precision, recall, f1 = score_cases(pred_cases, gold_cases)
            row = {
                "doc_id": record["doc_id"], "response": response,
                "pred_treatment": pred_treatment, "pred_cases": pred_cases,
                "gold_treatment": gold_treatment, "gold_cases": gold_cases,
                "treatment_correct": (pred_treatment == gold_treatment) if gold_treatment else None,
                "cases_precision": precision, "cases_recall": recall, "cases_f1": f1,
                "parse_failed": pred_treatment is None,
                "input_tokens": in_tok, "output_tokens": out_tok,
                "latency_s": round(latency, 2),
            }
            rows.append(row)
            outf.write(json.dumps(row, ensure_ascii=False) + "\n")
            outf.flush()
            print(f"  [{i+1}/{len(records)}] {record['doc_id']}  treatment={pred_treatment} "
                  f"(gold {gold_treatment})  f1={f1:.2f}  {latency:.1f}s", flush=True)

    n = len(rows)
    scored = [r for r in rows if r["gold_treatment"]]
    summary = {
        "run_name": args.run_name, "split": args.split, "n_records": n,
        "hyperparameters": {"temperature": args.temperature, "top_p": args.top_p,
                            "max_new_tokens": args.max_new_tokens},
        "citation_treatment_accuracy": round(sum(r["treatment_correct"] for r in scored) / len(scored), 3) if scored else None,
        "cited_cases_precision": round(sum(r["cases_precision"] for r in rows) / n, 3),
        "cited_cases_recall": round(sum(r["cases_recall"] for r in rows) / n, 3),
        "cited_cases_f1": round(sum(r["cases_f1"] for r in rows) / n, 3),
        "parse_failure_rate": round(sum(r["parse_failed"] for r in rows) / n, 3),
        "mean_input_tokens": round(sum(r["input_tokens"] for r in rows) / n, 1),
        "mean_output_tokens": round(sum(r["output_tokens"] for r in rows) / n, 1),
        "mean_latency_s": round(sum(r["latency_s"] for r in rows) / n, 2),
        "total_time_s": round(time.time() - t_start, 1),
        "device": str(device),
    }
    (Path("out") / f"{args.run_name}_summary.json").write_text(json.dumps(summary, indent=2))
    print("\nSUMMARY " + json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
