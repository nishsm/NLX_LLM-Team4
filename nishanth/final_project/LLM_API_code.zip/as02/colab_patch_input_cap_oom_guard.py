# Notebook cell 10 (AS02_llmbox_colab.ipynb): caps input at MAX_INPUT_TOKENS and returns [OOM] instead of crashing
# PATCH: cap input length + survive GPU out-of-memory. Run once, then re-run the eval cells.
import os
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
os.environ["MAX_INPUT_TOKENS"] = "6000"

HELPERS = '''
import os as _os
MAX_INPUT_TOKENS = int(_os.environ.get("MAX_INPUT_TOKENS", "6000"))

def truncate_text(tokenizer, text, max_tokens=None):
    max_tokens = max_tokens or MAX_INPUT_TOKENS
    ids = tokenizer(text, add_special_tokens=False)["input_ids"]
    if len(ids) <= max_tokens:
        return text
    return tokenizer.decode(ids[:max_tokens])

def make_oom_safe(gen):
    import torch
    orig = gen._generate_once
    def safe(*a, **k):
        try:
            return orig(*a, **k)
        except torch.OutOfMemoryError:
            torch.cuda.empty_cache()
            return "[OOM]"
    gen._generate_once = safe
'''

for path in ["run_baseline_eval.py", "run_custom_eval.py"]:
    src = open(path).read()
    if "MAX_INPUT_TOKENS" in src:
        print(path, "already patched"); continue
    src = src.replace("from src.generation import GenerationManager\n",
                      "from src.generation import GenerationManager\n" + HELPERS, 1)
    src = src.replace("f\"Opinion:\\n{record['raw_text']}\"",
                      "f\"Opinion:\\n{truncate_text(tokenizer, record['raw_text'])}\"")
    src = src.replace("    gen = GenerationManager()\n",
                      "    gen = GenerationManager()\n    make_oom_safe(gen)\n", 1)
    compile(src, path, "exec")
    open(path, "w").write(src)
    print(path, "patched:", src.count("truncate_text(tokenizer"), "truncation point(s), OOM guard on")