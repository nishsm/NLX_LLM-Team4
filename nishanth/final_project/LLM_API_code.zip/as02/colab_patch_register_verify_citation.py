# Notebook cell 9 (AS02_llmbox_colab.ipynb): registers verify_citation in LLMBox TOOL_REGISTRY
# Register the verify_citation tool in LLMBox's tool registry (skipped if already there)
TOOL_PATCH = '\n# --------------------------------------------------------------------------\n# verify_citation -- legal aid clinic tool: check a case citation against the\n# known-citation index (built from the corpus\'s own table_json) before it\n# goes into a filed brief. Exact match, case-insensitive; can confirm, never\n# deny (absence from the index is not proof a citation is fake).\n# --------------------------------------------------------------------------\nimport json as _json\nfrom pathlib import Path as _Path\n\n_CITATION_INDEX_PATH = _Path(__file__).resolve().parent.parent / "citation_index.json"\ntry:\n    _CITATION_INDEX = _json.loads(_CITATION_INDEX_PATH.read_text(encoding="utf-8"))\nexcept FileNotFoundError:\n    _CITATION_INDEX = {}\n_CITATION_LOOKUP = {k.strip().lower(): (k, v) for k, v in _CITATION_INDEX.items()}\n\n\n@register_tool("verify_citation")\ndef verify_citation(case_name):\n    if not isinstance(case_name, str) or not case_name.strip():\n        return {"verified": False, "error": "case_name must be a non-empty string"}\n    hit = _CITATION_LOOKUP.get(case_name.strip().lower())\n    if hit:\n        return {"verified": True, "matched_name": hit[0],\n                "citation_class_in_corpus": hit[1].get("citation_class")}\n    return {"verified": False, "matched_name": None}\n'
src = open('src/tools.py').read()
if 'register_tool("verify_citation")' not in src:
    open('src/tools.py', 'a').write(TOOL_PATCH)
    print('added verify_citation to src/tools.py')
else:
    print('verify_citation already registered')
import json
print(len(json.load(open('citation_index.json'))), 'citations in index')