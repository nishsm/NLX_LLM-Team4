# Assignment 1 — Corpus Construction and Characterization

## Group Topic

AI-Assisted Legal Case Research

The group project considers a legal-technology application in which an LLM-based API assists lawyers with case-law research. Given a legal question and a collection of court opinions, the proposed system would retrieve relevant cases and produce structured summaries of supporting legal evidence.

## Individual Subtopic

Intellectual Property Case Law

My individual corpus focuses on intellectual property cases, including copyright, trade mark, patent, passing-off, design, and related intellectual-property disputes.

## Corpus Contents

The final corpus contains 214 Australian Federal Court case reports from 2006–2009.

Corpus size: 214 records

Modalities:
- 213 mixed text/table records
- 1 text-only record
- 99.5% of records contain tabular or semi-structured information

Each corpus record contains the required top-level fields:

- `doc_id`
- `source_url`
- `retrieved_at`
- `modality`
- `raw_text`
- `table_json`
- `license_note`
- `metadata`

The metadata includes information such as case name, year, court, subtopic, source filename, catchphrases, and available citation counts.

## Data Source

The corpus was constructed from the UCI Legal Case Reports dataset. The underlying case reports were originally obtained from the Australasian Legal Information Institute (AustLII).

The dataset contains Australian Federal Court decisions and associated citation information.

The UCI dataset documentation states that the dataset is for research use, redistribution is prohibited, and the associated research papers should be cited when the data is used in a publication. This restriction is recorded in `sources.csv` and in each corpus record's `license_note`.

Because of this restriction, the corpus should not be publicly redistributed or uploaded to a public dataset repository.

## Collection and Preprocessing

The downloaded Legal Case Reports dataset contains full-text case files as well as citation summary and citation classification information.

The full-text source files were processed into individual case records. Because the source files contain XML-like markup that is not consistently well formed, the corpus-building process used text-based parsing rather than relying on strict XML parsing.

Cases relevant to the intellectual-property subtopic were selected using IP-related terms in the case catchphrases, including:

- copyright
- trade mark
- trademark
- patent
- intellectual property
- passing off

This filtering produced 214 case records.

Where available, citation summary and citation classification information was incorporated as structured or semi-structured information in `table_json`. All 214 selected cases had citation-summary information, while 144 also had citation-classification information.

## Extraction Task

The Phi-4-mini-instruct evaluation uses three structured extraction fields:

1. `ip_area` — the primary intellectual-property area discussed in the document. Allowed labels are `copyright`, `trademark`, `patent`, `passing_off`, `other`, and `unclear`.

2. `legislation_cited` — titles of legislation explicitly appearing in the supplied document or structured information.

3. `relief_sought` — forms of legal relief explicitly stated as being sought or claimed in the case.

A random sample of 25 corpus records was manually labelled in `human_labels.jsonl` and used for the Human-vs-Phi evaluation.

## Sensitive-Information Review

A Phi-4-mini-instruct sensitive-information screening was tested using the provided `mask_sensitive.py` workflow on a five-record sample of the corpus, using the first 3,000 characters of each sampled record.

Phi proposed 20 sensitive spans. Eighteen passed the script's automatic verbatim check and two were rejected as non-verbatim. Manual inspection showed substantial false positives among the accepted proposals, including public company names, ordinary litigation dates, and public case or designation identifiers.

Because automatically applying these proposals would remove legally meaningful public case information and could alter structural identifiers, the automatically masked sample was not substituted for the final corpus. The screening output was manually reviewed rather than accepted without inspection.

## Corpus Characterization

The corpus contains 214 documents from one source domain.

Document length varies substantially:

- Minimum: 1,486 characters
- Median: 38,086.5 characters
- 95th percentile: 176,959.3 characters
- Maximum: 1,295,444 characters

The corpus contains no detected near-duplicate records under the provided corpus-analysis procedure.

K-means clustering was performed with six clusters. The resulting silhouette score was 0.022, indicating weak separation between clusters. Manual cluster reading nevertheless showed recurring themes including patent disputes, trade mark disputes, mixed IP litigation, procedural trade mark matters, copyright/commercial IP disputes, and counterfeit trade mark/Customs matters.

## Limitations

The corpus comes from a single underlying legal source and is limited to Australian Federal Court cases from 2006–2009, so it does not represent current law or other jurisdictions.

The keyword-based IP filtering procedure may miss cases in which intellectual-property issues are not clearly represented in the catchphrases and may overrepresent cases using the selected terminology.

The source files contain inconsistent XML-like markup, so text-based parsing was necessary and some markup artifacts may remain in extracted text.

For Phi extraction, the model receives a truncated portion of each record rather than every character of very long opinions. Relevant evidence occurring later in a case may therefore be unavailable to the model.

The six-cluster solution has a low silhouette score (0.022), so the cluster labels should be interpreted as descriptive reading aids rather than strongly separated natural categories.

The sensitive-information screening experiment also showed that Phi can produce false positives on public legal information, making manual review necessary before accepting automatic masking decisions.
